import Draggabilly from 'draggabilly';
import interact from 'interactjs';

const desktop = document.getElementById('desktop');
const windowContainer = document.getElementById('window-container');
let highestZ = 500; // Initial highest z-index for windows

// --- Window Management ---

function bringToFront(windowElement) {
    // Remove active class from all windows
    document.querySelectorAll('.window.active-window').forEach(win => {
        win.classList.remove('active-window');
        // Optionally reset z-index if not managing incrementally
        // win.style.zIndex = 100;
    });
    // Add active class and set highest z-index to the clicked window
    highestZ++;
    windowElement.style.zIndex = highestZ;
    windowElement.classList.add('active-window');
}

function createWindow(appId, title, contentHtml = '') {
    // Check if window already exists
    const existingWindow = document.querySelector(`.window[data-app-id="${appId}"]`);
    if (existingWindow) {
        bringToFront(existingWindow);
        return; // Don't create a duplicate
    }

    const win = document.createElement('div');
    win.className = 'window';
    win.dataset.appId = appId;

    // Center new windows roughly
    const offsetX = (document.querySelectorAll('.window').length % 5) * 30; // Cascade slightly
    const offsetY = (document.querySelectorAll('.window').length % 5) * 30;
    win.style.left = `calc(50% - 200px + ${offsetX}px)`; // Adjust based on default width
    win.style.top = `calc(50% - 150px + ${offsetY}px)`; // Adjust based on default height

    win.innerHTML = `
        <div class="window-titlebar">
            <span class="window-title">${title}</span>
            <div class="window-controls">
                <button class="close-btn" title="Close">×</button>
                <!-- Add minimize/maximize buttons here if needed -->
            </div>
        </div>
        <div class="window-content">
            ${contentHtml || `<p>Content for ${title} goes here.</p><p>This window is draggable and resizable!</p>`}
        </div>
    `;

    windowContainer.appendChild(win);
    bringToFront(win); // Make the new window active

    // --- Make window draggable and resizable using Interact.js ---
    interact(win)
        .draggable({
            allowFrom: '.window-titlebar', // Only drag from titlebar
            inertia: true,
            modifiers: [
                interact.modifiers.restrictRect({
                    restriction: 'parent', // Keep within #window-container (effectively the desktop)
                    endOnly: true
                })
            ],
            listeners: {
                move(event) {
                    const target = event.target;
                    let x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx;
                    let y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy;

                    target.style.transform = `translate(${x}px, ${y}px)`;
                    target.setAttribute('data-x', x);
                    target.setAttribute('data-y', y);
                }
            }
        })
        .resizable({
            edges: { left: true, right: true, bottom: true, top: false }, // Allow resize from sides and bottom
            listeners: {
                move(event) {
                    let target = event.target;
                    let x = (parseFloat(target.getAttribute('data-x')) || 0);
                    let y = (parseFloat(target.getAttribute('data-y')) || 0);

                    // Update the element's style
                    target.style.width = event.rect.width + 'px';
                    target.style.height = event.rect.height + 'px';

                     // translate when resizing from top or left edges
                    // x += event.deltaRect.left;
                    // y += event.deltaRect.top;

                    // target.style.transform = 'translate(' + x + 'px,' + y + 'px)';
                    // target.setAttribute('data-x', x);
                    // target.setAttribute('data-y', y);
                    // target.textContent = Math.round(event.rect.width) + '\u00D7' + Math.round(event.rect.height)
                }
            },
            modifiers: [
                // keep the edges inside the parent
                interact.modifiers.restrictEdges({
                    outer: 'parent'
                }),

                // minimum size
                interact.modifiers.restrictSize({
                    min: { width: 200, height: 150 }
                })
            ],
            inertia: false // Resizing inertia usually feels weird
        })
        .on('down', (event) => {
             // Bring window to front on click/tap
            bringToFront(event.currentTarget);
        });


    // --- Add close button functionality ---
    const closeButton = win.querySelector('.close-btn');
    closeButton.addEventListener('click', (e) => {
        e.stopPropagation(); // Prevent triggering focus on the window
        win.remove();
        // Optional: Add fade out animation later
    });

     // Bring window to front when interacted with
     win.addEventListener('mousedown', () => bringToFront(win));
     win.addEventListener('touchstart', () => bringToFront(win), { passive: true });


    // Special content/setup based on appId
    if (appId === 'player') {
        const content = win.querySelector('.window-content');
        content.innerHTML = '▶️'; // Simple placeholder
    }
     if (appId === 'web-browser') {
        const content = win.querySelector('.window-content');
        content.innerHTML = `<p>Simple Browser Frame</p><iframe src="about:blank" style="width: 100%; height: calc(100% - 30px); border: none;"></iframe>`;
        // You could add basic controls (address bar, back/forward) here later
    }

}


// --- Icon Draggability (using Draggabilly) ---
const icons = document.querySelectorAll('.icon');
icons.forEach(icon => {
    const draggie = new Draggabilly(icon, {
        containment: '#desktop'
    });
    icon.addEventListener('pointerDown', () => { icon.style.cursor = 'grabbing'; });
    icon.addEventListener('pointerUp', () => { icon.style.cursor = 'grab'; });

    // --- Desktop Icon Double Click ---
    icon.addEventListener('dblclick', () => {
        const appId = icon.dataset.appId;
        const appTitle = icon.dataset.appTitle || 'Application';
        console.log(`Double-clicked ${appTitle} (ID: ${appId})`);
        createWindow(appId, appTitle);
    });
});


// --- Dock Icon Click ---
const dockIcons = document.querySelectorAll('.dock-icon');
dockIcons.forEach(dockIcon => {
    dockIcon.addEventListener('click', () => {
        const appId = dockIcon.dataset.appId;
        const appTitle = dockIcon.getAttribute('title') || 'Dock App';
         if (!appId) return; // Ignore separator or clock
        console.log(`Clicked ${appTitle} (ID: ${appId})`);
        createWindow(appId, appTitle);
    });
});


// --- Clock Functionality ---
const clockElement = document.getElementById('clock');
function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    clockElement.textContent = `${hours}:${minutes}`;
}
updateClock();
setInterval(updateClock, 60000); // Update every minute is enough

// --- Initial Setup ---
// Example: Open a welcome window on load?
// createWindow('welcome', 'Welcome!', '<p>Welcome to AnimeOS Concept!</p>');