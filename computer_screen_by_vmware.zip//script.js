document.addEventListener('DOMContentLoaded', () => {
  const timeElement = document.querySelector('.time');
  const desktopIcons = document.querySelectorAll('.desktop-icon');
  const windows = document.querySelectorAll('.window');
  const activeWindows = document.querySelector('.active-windows');
  const powerButton = document.querySelector('.power-button');
  const screenContent = document.querySelector('.screen-content');
  let isPoweredOn = true;

  // Power button functionality
  powerButton.addEventListener('click', (e) => {
    e.stopPropagation();
    if (isPoweredOn) {
      const powerMenu = document.querySelector('.power-menu');
      powerMenu.classList.toggle('active');
      powerButton.classList.toggle('active');
    }
  });

  function updateTime() {
    if (isPoweredOn) {
      const now = new Date();
      timeElement.textContent = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    }
  }

  updateTime();
  setInterval(updateTime, 1000);

  // Window management
  function createWindowTab(windowId, title) {
    if (!isPoweredOn) return null;
    const tab = document.createElement('div');
    tab.className = 'window-tab';
    tab.textContent = title;
    tab.dataset.window = windowId;
    return tab;
  }

  function activateWindow(windowId) {
    if (!isPoweredOn) return;

    const windows = document.querySelectorAll('.window');
    windows.forEach(window => {
      if (window.id === `${windowId}-window`) {
        window.classList.add('active');
        window.style.zIndex = '10';

        // Reset position if not maximized
        if (!window.classList.contains('maximized')) {
          window.style.top = '50%';
          window.style.left = '50%';
          window.style.transform = 'translate(-50%, -50%)';
        }
      } else {
        window.classList.remove('active');
        window.style.zIndex = '1';
      }
    });

    // Update taskbar tabs
    const tabs = activeWindows.querySelectorAll('.window-tab');
    tabs.forEach(tab => {
      tab.classList.toggle('active', tab.dataset.window === windowId);
    });
  }

  // Desktop icon click handlers
  desktopIcons.forEach(icon => {
    icon.addEventListener('click', () => {
      if (!isPoweredOn) return;

      const windowId = icon.dataset.window;
      const windowElement = document.getElementById(`${windowId}-window`);

      if (!windowElement.classList.contains('active')) {
        const existingTab = activeWindows.querySelector(`[data-window="${windowId}"]`);
        if (!existingTab) {
          const tab = createWindowTab(windowId, icon.querySelector('span').textContent);
          activeWindows.appendChild(tab);

          tab.addEventListener('click', () => {
            activateWindow(windowId);
          });
        }
      }

      activateWindow(windowId);
    });
  });

  // Add start menu
  const startMenu = document.createElement('div');
  startMenu.className = 'start-menu';

  // Create tiles container
  const tilesContainer = document.createElement('div');
  tilesContainer.className = 'start-tiles';

  // Add tiles for each desktop icon
  desktopIcons.forEach(icon => {
    const tile = document.createElement('div');
    tile.className = 'start-tile';
    tile.innerHTML = icon.innerHTML;
    tile.dataset.window = icon.dataset.window;

    tile.addEventListener('click', () => {
      const windowId = tile.dataset.window;
      startMenu.classList.remove('active');
      powerButton.classList.remove('active');

      // Trigger window open
      const windowElement = document.getElementById(`${windowId}-window`);
      if (windowElement) {
        const existingTab = document.querySelector(`.window-tab[data-window="${windowId}"]`);
        if (!existingTab) {
          const tab = createWindowTab(windowId, tile.querySelector('span').textContent);
          document.querySelector('.active-windows').appendChild(tab);

          tab.addEventListener('click', () => {
            activateWindow(windowId);
          });
        }
        activateWindow(windowId);
      }
    });

    tilesContainer.appendChild(tile);
  });

  startMenu.appendChild(tilesContainer);
  document.body.appendChild(startMenu);

  // Close start menu when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.start-menu') && !e.target.closest('.power-button')) {
      startMenu.classList.remove('active');
      powerButton.classList.remove('active');
    }
  });

  function showVMwareRestart() {
    const vmwareScreen = document.querySelector('.vmware-restart');
    vmwareScreen.style.display = 'flex';
    
    // Animate progress bar
    const progressBar = vmwareScreen.querySelector('.vmware-progress-bar');
    let progress = 0;
    const progressInterval = setInterval(() => {
      progress += 1;
      progressBar.style.width = progress + '%';
      if (progress >= 100) {
        clearInterval(progressInterval);
        setTimeout(() => window.location.reload(), 500);
      }
    }, 50);
  }

  // Power menu functionality
  document.querySelectorAll('.power-option').forEach(option => {
    option.addEventListener('click', () => {
      const action = option.dataset.action;
      document.querySelector('.power-menu').classList.remove('active');
      powerButton.classList.remove('active');

      switch(action) {
        case 'shutdown':
          screenContent.classList.add('power-off');
          isPoweredOn = false;
          break;
        case 'sleep':
          screenContent.classList.add('sleep');
          setTimeout(() => {
            screenContent.classList.remove('sleep');
            screenContent.classList.add('power-off');
            isPoweredOn = false;
          }, 1000);
          break;
        case 'restart':
          screenContent.classList.add('restart');
          setTimeout(() => {
            showVMwareRestart();
          }, 1000);
          break;
      }
    });
  });

  // Update Settings functionality
  const checkUpdatesBtn = document.getElementById('check-updates');
  const updateStatus = document.getElementById('update-status');

  if (checkUpdatesBtn && updateStatus) {
    checkUpdatesBtn.addEventListener('click', () => {
      checkUpdatesBtn.disabled = true;
      checkUpdatesBtn.textContent = 'Checking for updates...';
      updateStatus.style.color = '#FFC107';
      updateStatus.textContent = 'Checking for updates...';

      setTimeout(() => {
        updateStatus.style.color = '#2196F3';
        updateStatus.textContent = 'Update found! Installing...';
        checkUpdatesBtn.textContent = 'Installing update...';

        setTimeout(() => {
          updateStatus.style.color = '#4CAF50';
          updateStatus.textContent = 'Update installed! Restart required.';
          checkUpdatesBtn.textContent = 'Restart now';
          checkUpdatesBtn.disabled = false;

          checkUpdatesBtn.addEventListener('click', () => {
            showVMwareRestart();
          }, { once: true });
        }, 3000);
      }, 2000);
    });
  }

  // Rest of your code...
});